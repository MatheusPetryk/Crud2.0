<h1>nova lista</h1>
<?php
    $sql = "SELECT * FROM dados";

    $res = $conn->query($sql);

    $qtd = $res->num_rows;

    if($qtd > 0){
        print "<table class='table table-holver table-striped table-bordered'>";
        
        print "<tr>";
        print "<th>Código</th>";
        print "<th>Nome</th>";
        print "<th>Fabricante</th>";
        print "<th>Descrição</th>";
        print "<th>Quantidade</th>";
        print "<th>Ações</th>";
        print "</tr>";
        while($row = $res->fetch_object()){
            print "<tr>";
            print "<td>" .$row->codigo ."</td>";
            print "<td>" .$row->nome ."</td>";
            print "<td>" .$row->fabricante ."</td>";
            print "<td>" .$row->descricao ."</td>";
            print "<td>" .$row->quantidade ."</td>";
            print "<td>
                <button onclick=\"
                location.href = '?page=editar&codigo=".$row -> codigo."';\" class='btn btn-success'>Editar</button>
                
                <button onclick=\"if(confirm('deseja excluir?')){location.href = '?page=salvar&acao=excluir&codigo=".$row -> codigo."';}else{false;}\" class='btn btn-danger'>Apagar</button>
            </td>";
            print "</tr>";
        }
        print "</table>";
    }else{
        print"<p class='alert alert-danger'>Não encontrou resultados!</p>";
    }
?>