<?php
switch ($_REQUEST["acao"]) {
    case 'cadastrar':
       $nome = $_POST["nome"];
       $fabricante = $_POST["fabricante"];
       $descricao = $_POST["descricao"];
       $quantidade = $_POST["quantidade"];

       $sql = "INSERT INTO dados (nome, fabricante, descricao, quantidade)
    VALUES('{$nome}','{$fabricante}','{$descricao}','{$quantidade}' )";

       $res = $conn->query($sql);

       if ($res==true) {
           print "<script>alert('cadastro com sucesso');
           </script>";
           print "<script>location.href='?page=listar';
           </script>";
       }
       else{
        print "<script>alert('não foi possivel');
        </script>";
        print "<script>location.href='?page=listar';
        </script>"; 
       }


        break;
    
    case 'editar':
        $nome = $_POST["nome"];
        $fabricante = $_POST["fabricante"];
        $descricao = $_POST["descricao"];
        $quantidade = $_POST["quantidade"];

        $sql="UPDATE dados SET
                       nome='{$nome}' 
                       fabricante='{$fabricante}' 
                       descricao='{$descricao}' 
                       quantidade='{$quantidade}'
                       WHERE
                       codigo=".$_REQUEST["codigo"];




$res = $conn->query($sql);

        if ($res==true) {
            print "<script>alert('editado com sucesso');
            </script>";
            print "<script>location.href='?page=listar';
            </script>";
        }
        else{
         print "<script>alert('não foi possivel');
         </script>";
         print "<script>location.href='?page=listar';
         </script>"; 
        }
 
        break;

    case 'excluir':
                $slq = "DELETE FROM dados WHERE codigo=".$_REQUEST["codigo"];

                $res = $conn->query($sql);
                
                if ($res==true) {
                    print "<script>alert('excluido com sucesso'); 
                    </script>";
                    print "<script>location.href='?page=listar';
                    </script>";
                }
                else{
                 print "<script>alert('não foi possivel');
                 </script>";
                 print "<script>location.href='?page=listar';
                 </script>"; 
                }
                break;
}







?>